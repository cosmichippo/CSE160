function setupWebGL(){
    var canvas = document.getElementById('webgl');
  
    // Get the rendering context for WebGL
    var gl = canvas.getContext("webgl",{preserveDrawingBuffer: true});//getWebGLContext(canvas);
    if (!gl) {
      console.log('Failed to get the rendering context for WebGL');
      return;
    }else{
      return {canvas, gl};
    }
  }

function connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE){

  // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  // // Get the storage location of a_Position
  var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return;
  }

  // Get the storage location of u_FragColor
  var u_FragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
  if (!u_FragColor) {
    console.log('Failed to get the storage location of u_FragColor');
    return;
  }

  return {a_Position, u_FragColor};
}


function renderAllShapes(gl, a_Position, u_FragColor, vertexBuffer, shapes){
  gl.clearColor(0.0, 0.0, 0.0, 1.0);
  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);
  
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  
  for(let i = 0; i < shapes.length; i++){
    let current_shape = shapes[i];
    let color = shapes[i].color;
    gl.uniform4f(u_FragColor, color[0], color[1], color[2], color[3]); //red 
  
    //console.log("  ", current_shape.vertices[0], current_shape.vertices[1]);
    
    gl.bufferData(gl.ARRAY_BUFFER, current_shape.vertices, gl.STATIC_DRAW);
    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
    // Enable the assignment to a_Position variable
    gl.enableVertexAttribArray(a_Position);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, current_shape.size);
  }
}

function initVertexBuffers(gl) {
    var vertices = new Float32Array([
      0, 0.5,   -0.5, -0.5,   0.5, -0.5
    ]);
    var n = 3; // The number of vertices
  
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed to create the buffer object');
      return -1;
    }
    // Bind the buffer object to target
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    // Write date into the buffer object
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
  
    var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    if (a_Position < 0) {
      console.log('Failed to get the storage location of a_Position');
      return -1;
    }
    // Assign the buffer object to a_Position variable
    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  
    // Enable the assignment to a_Position variable
    gl.enableVertexAttribArray(a_Position);
  
    return n;
  }
    
function renderShape(gl, a_Position, u_FragColor, vertexBuffer, vertices, color, size, renderType){
    //gl.clearColor(0.0, 0.0, 0.0, 1.0);
    // Clear <canvas>
    //gl.clear(gl.COLOR_BUFFER_BIT);
    //let color = shape.color;
    //let vertices = shape.vertices;
    //let size = shape.size;
    //console.log();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.uniform4f(u_FragColor, color[0], color[1], color[2], color[3]);

  gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  // Enable the assignment to a_Position variable
  gl.enableVertexAttribArray(a_Position);
  gl.drawArrays(renderType, 0, size);

}


