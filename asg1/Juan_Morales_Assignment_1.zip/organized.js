// dependancies: "rendering.js, webgl-utils.js cuon-utils.js webgl-debug.js"
// ColoredPoint.js (c) 2012 matsuda
// Vertex shader program

var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' +
  'void main() {\n' +
  '  gl_Position = a_Position;\n' +
  '  gl_PointSize = 10.0;\n' +
  '}\n';

// Fragment shader program
var FSHADER_SOURCE =
  'precision mediump float;\n' +
  'uniform vec4 u_FragColor;\n' +  // uniform変数
  'void main() {\n' +
  '  gl_FragColor = u_FragColor;\n' +
  '}\n';

var state = 0; 

class Shape{
  constructor(vertices, color, size){

    this.vertices = new Float32Array(vertices);
    this.color = color;
    this.size = size;
  }
  drawShape(){
    var {canvas, gl} = setupWebGL();
    var {a_Position, u_FragColor} = connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE);
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed toi create the buffer object');
      return -1; 
    }
    console.log(this.vertices);
    renderShape(gl, a_Position, u_FragColor, vertexBuffer, this.vertices, this.color, this.size, gl.TRIANGLE_STRIP);
  }
}

class Triangle{
  constructor(x, y, color, scale){
    this.vertices = new Float32Array(Triangle.createTriangleCoords(x, y, scale));
    this.color = color;
  }
  
  drawTriangle(){
    var {canvas, gl} = setupWebGL();
    var {a_Position, u_FragColor} = connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE);
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed toi create the buffer object');
      return -1; 
    }
    console.log(this.vertices);
    renderShape(gl, a_Position, u_FragColor, vertexBuffer, this.vertices, this.color, 3, gl.TRIANGLES);
  }

  static createTriangleCoords(x, y, scale = 1){
    return [ (1/scale) + x, (Math.sqrt(3)/scale) + y, 0 + x,0 + y, (2/scale) + x, 0+ y]
  }

}

class Square{
  constructor(x, y, color, scale){

    this.vertices = new Float32Array(Square.createSquareCoords(x, y, scale));
    
    //this.vertices = new Float32Array(vertices);
    this.color = color;
    this.size = 4;
  }

  drawSquare(){
    var {canvas, gl} = setupWebGL();
    var {a_Position, u_FragColor} = connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE);
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed to create the buffer object');
      return -1; 
    }
    console.log(this.vertices);
    renderShape(gl, a_Position, u_FragColor, vertexBuffer, this.vertices, this.color, this.size, gl.TRIANGLE_STRIP);
  }

  static createSquareCoords(x, y, scale = 1){
    var test = [0, 2/scale, 0, 0, 2/scale, 2/scale, 2/scale, 0];
    for (let i = 0; i < 8; i++){
      if (i % 2 == 0){
        test[i] += x;
      }else{
        test[i] += y;
      }
    }

    return test;
  
  }

}

class Circle{
  constructor(x, y, color, nodes, scale){
    this.vertices = new Float32Array(translate_to_mouse_pos(createCircleCoords(nodes, scale), x, y));
    this.color = color;
    this.size = nodes;
  }
  drawCircle(){
    var {canvas, gl} = setupWebGL();
    var {a_Position, u_FragColor} = connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE);
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed toi create the buffer object');
      return -1; 
    }
    console.log(this.vertices);
    renderShape(gl, a_Position, u_FragColor, vertexBuffer, this.vertices, this.color, this.size, gl.TRIANGLE_FAN);
  }
}


//amount of nodes == fidelity of circle
function createCircleCoords(nodes, scale){
  let coords = [];
  for (let i = 0; i <= nodes; i++){
    let theta = (Math.PI * i * 2)/nodes;
    coords.push(Math.cos(theta)/scale);
    coords.push(Math.sin(theta)/scale);
  }
  return coords;
}

function translate_to_mouse_pos(arr, x, y){
  for(let j = 0; j < arr.length; j++){
    if (j % 2 == 0){
      arr[j] += x;
    }else{
      arr[j] += y;
    }
  }
  return arr;
}
function on_circle(){
  state = 0;
}
function on_square(){
  state = 1;
}
function on_triangle(){
  state = 2;
}


function on_clear(){
  var {canvas, gl} = setupWebGL();
  gl.clearColor(0.0, 0.0, 0.0, 1.0);
  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);
}

var color_display;
var myData = [
                [[-10/16, -1/16, -13/16, -2/16, -10/16, -2/16, -1, -2/16, -1, -8/16, -10/16, -2/16, -10/16, -9/16, -6/16, -9/16, -6/16, -11/16], [64.4/100, 12/100, 1.6/100, 1.0], 9], //left arm
                [[10/16, -1/16, 13/16, -2/16, 10/16, -2/16, 1, -2/16, 1, -8/16, 10/16, -2/16, 9/16, -9/16, 6/16, -9/16, 6/16, -11/16], [64.4/100, 12/100, 1.6/100, 1.0], 9], //left arm

                [[-16/16,10/16,-6/16,10/16,-10/16,6/16],[1.0, 0.0, 0.0, 1.0],3],//ear?
                [[16/16,10/16,6/16,10/16,10/16,6/16],[1.0, 0.0, 0.0, 1.0],3],//ear?

                [[-15/16, 9/16, -9/16, 9/16, -12/16, 6/16, -9/16, 6/16], [1.0, 0.0, 0.0, 1.0], 4],//ear part
                [[15/16, 9/16, 9/16, 9/16, 12/16, 6/16, 9/16, 6/16], [1.0, 0.0, 0.0, 1.0], 4],//ear part
                //[[15/16, 9/16, 9/16, 9/16, 12/16, 6/16, 9/16, 6/16], [1.0, 0.0, 0.0, 1.0], 4],//ear part


                [[0, 10/16, -7/16, 9/16, 7/16, 9/16, -10/16, 6/16, 10/16, 6/16, -11/16, 0, 11/16, 0, -5/16, -1, 4/16, -1], [70/100, 20/100, 3/100, 1.0], 9],//body
                [[-7/16, 2/16, -10/16, -1/16, -6/16, -1/16, -6/16, -9/16, -3/16, -9/16], [72/100, 44/100, 44/100, 1.0] , 5],//under nose
                [[7/16, 2/16, 10/16, -1/16, 6/16, -1/16, 6/16, -9/16, 3/16, -9/16], [72/100, 44/100, 44/100, 1.0] , 5],//under nose right

                [[ -6/16,-9/16, 5/16, -9/16, -4/16, -1, 3/16, -1], [64/100, 33/100, 2/100, 1.0], 4], //under mouth part

                [[-7/16, 10/16, -3/16, 8/16, -8/16, 8/16], [1.0, 0.5, 0.0, 1.0], 3],//idk
                [[7/16, 10/16, 3/16, 8/16, 8/16, 8/16], [1.0, 0.5, 0.0, 1.0], 3],//idk
                [[0, -7/16, -4/16, -10/16, 0, -13/16, 0, -7/16, 6/16, -9/16], [8/100, 5/100, 30/100, 1.0], 5],//nose

                [[0, 6/16, -9/16, 6/16, -2/16, 4/16], [1.0, 1.0, 1.0, 1.0], 3],//ear part

                [[0, 6/16, 9/16, 6/16, 2/16, 4/16], [1.0, 1.0, 1.0, 1.0], 3]//ear part

              ];


function main() {
  var slider = document.getElementById("myRange");
  var output = document.getElementById("slider_output");
  slider.oninput = function() {
    output.innerHTML = this.value;
  }
  color_display = document.getElementById("color_display");
  // Retrieve <canvas> element
  var {canvas, gl} = setupWebGL();

  var {a_Position, u_FragColor} = connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE);
    // Create a buffer object
  var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed to create the buffer object');
      return -1;
    }
  
  // Register function (event handler) to be called on a mouse press
  canvas.onmousedown = function(ev){ handleClicks(ev, gl, canvas, a_Position, u_FragColor, vertexBuffer) };

  canvas.onmousemove = function(ev){ handleClicks(ev, gl, canvas, a_Position, u_FragColor, vertexBuffer) };
  
  // Specify the color for clearing <canvas>
  gl.clearColor(0.0, 0.0, 0.0, 1.0);

  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);
}

var range = document.getElementById("myRange");
var myScale = document.getElementById("scaleRange");

function handleClicks(ev, gl, canvas, a_Position, u_FragColor, vertexBuffer) {
  if(ev.buttons != 1){
    return;
  }
  //console.log(test.value);
  var n = Number(range.value);
  var scale = Number(myScale.value);
  var {r, g, b} = grabColors();
  var color = [r/255, g/255, b/255, 1.0];

  var x = ev.clientX; // x coordinate of a mouse pointer
  var y = ev.clientY; // y coordinate of a mouse pointer
  var rect = ev.target.getBoundingClientRect();
  x = ((x - rect.left) - canvas.width/2)/(canvas.width/2);
  y = (canvas.height/2 - (y - rect.top))/(canvas.height/2);
  
  console.log(x,y);
  if (state == 0){
    test = new Circle(x, y, color, n, scale);
    test.drawCircle();
  }else if (state == 1){
    test = new Square(x, y, color, scale);
    test.drawSquare();
  }else if (state == 2){
    test = new Triangle(x, y, color, scale);
    test.drawTriangle();
  }
}

function grabColors(){
  var red = document.getElementById("red");
  var green = document.getElementById("green");
  var blue = document.getElementById("blue");
  var r = Number(red.value); var g = Number(green.value); var b = Number(blue.value);
  return {r, g, b};
}


function update_canva2(){
  let {r, g, b} = grabColors();
  var ctx = color_display.getContext("2d");
  ctx.clearRect(0,0,color_display.width, color_display.height);
  ctx.rect(0,0,color_display.width, color_display.height);
  ctx.fillStyle = rgb_to_hex(r,g,b);
  ctx.fill();
}

function rgb_to_hex(r,g,b){
  return "#"+ componentToHex(r) + componentToHex(g) + componentToHex(b);
}
function componentToHex(c) {
  var hex = c.toString(16);
  return hex.length == 1 ? "0" + hex : hex;
}


function specialButtonHandler(){
  var test_arr = [];
  for(let i = 0; i < myData.length; i++){
      let foo = myData[i];
      test_arr.push(new Shape(foo[0], foo[1], foo[2]));
  }
  for (let i = 0; i < test_arr.length; i++){
    test_arr[i].drawShape();
  }
  

}