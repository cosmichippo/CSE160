class Cube{
    constructor(){
        this.type = 'cube';
        //this.vertices = 
        this.color = [1.0, 1.0, 1.0, 1.0];
        this.matrix = new Matrix4();
        //this.segments = 10;
        this.buffer = null;
        this.offset = 0;
    }
    
    render(){
      if (this.buffer === null){
        this.buffer = gl.createBuffer();
       if (!this.buffer) {
        console.log('Failed toi create the buffer object');
        return -1; 
      }
    }

    //gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    const uFragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
    if (!uFragColor){
        console.log("Failed to get color");
    }
    var rgb = this.color;
    //console.log(rgb);
    gl.uniform4f(uFragColor, rgb[0], rgb[1] , rgb[2], rgb[3]);
    //console.log(this.vertices);
    gl.uniformMatrix4fv(u_ModelMatrix, false, this.matrix.elements);
    //front
    renderTriangle3D(this.buffer, [0,0,0, 1,1,0, 1,0,0], this.color);
    renderTriangle3D(this.buffer, [0,0,0, 0,1,0, 1,1,0], this.color);
    //back
    gl.uniform4f(uFragColor, rgb[0]*0.4,rgb[1]*0.4 ,rgb[2]*0.4, rgb[3]*0.4);
    renderTriangle3D(this.buffer, [0,0,1, 1,1,1, 1,0,1], this.color);
    renderTriangle3D(this.buffer, [0,0,1, 0,1,1, 1,1,1], this.color);

    gl.uniform4f(uFragColor, rgb[0]*0.9,rgb[1]*0.9 ,rgb[2]*0.9, rgb[3]*0.9);
    //top
    renderTriangle3D(this.buffer, [0,1,0, 0,1,1, 1,1,1], this.color);
    renderTriangle3D(this.buffer, [0,1,0, 1,1,1, 1,1,0], this.color);
    
    gl.uniform4f(uFragColor, rgb[0]*0.8,rgb[1]*0.8 ,rgb[2]*0.8, rgb[3]*0.9);
    //right side
    renderTriangle3D(this.buffer, [1,0,0, 1,1,0, 1,1,1], this.color);
    renderTriangle3D(this.buffer, [1,0,0, 1,1,1, 1,0,1], this.color);
    //bottom
    gl.uniform4f(uFragColor, rgb[0],rgb[1]*0.4 ,rgb[2]*0.8, rgb[3]*0.9);
    renderTriangle3D(this.buffer, [0,0,0, 1,0,1, 0,0,1], this.color);
    renderTriangle3D(this.buffer, [0,0,0, 1,0,0, 1,0,1], this.color);

    gl.uniform4f(uFragColor, rgb[0]*0.4,rgb[1] ,rgb[2]*0.8, rgb[3]*0.9);
    //left
    renderTriangle3D(this.buffer, [0,0,0, 0,1,0, 0,1,1], this.color);
    renderTriangle3D(this.buffer, [0,0,0, 0,1,1, 0,0,1], this.color);

}
    moveYBySin(time){
        this.matrix.translate(0.0, Math.sin(time += this.offset), 0.0);
    }
    static createTriangleCoords(x, y, scale = 1){
      return [ (0.5/scale) + x, (Math.sqrt(3)/scale) + y, 0 + x,0 + y, (1/scale) + x, 0+ y]
    }
  
}
  