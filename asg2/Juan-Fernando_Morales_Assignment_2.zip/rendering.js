function setupWebGL(){
    canvas = document.getElementById('webgl');
  
    // Get the rendering context for WebGL
    gl = canvas.getContext("webgl",{preserveDrawingBuffer: true});//getWebGLContext(canvas);
    if (!gl) {
      console.log('Failed to get the rendering context for WebGL');
      return;
    }else{
      gl.enable(gl.DEPTH_TEST);
      return {canvas, gl};
    }
  }

function connectVariablesToGLSL(gl, VSHADER_SOURCE, FSHADER_SOURCE){

  // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  // // Get the storage location of a_Position
  a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return;
  }

  // Get the storage location of u_FragColor
  u_FragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
  if (!u_FragColor) {
    console.log('Failed to get the storage location of u_FragColor');
    return;
  }
  u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
  if (!u_ModelMatrix) {
    console.log('Failed to get the storage location of u_ModelMatrix');
    return;
  }
  u_GlobalRotateMatrix = gl.getUniformLocation(gl.program, 'u_GlobalRotateMatrix');
  if (!u_GlobalRotateMatrix) {
    console.log('Failed to get the storage location of u_GlobalRotateMatrix');
    return;
  }
  var identityMatrix = new Matrix4();
  gl.uniformMatrix4fv(u_ModelMatrix, false, identityMatrix.elements);

  return {a_Position, u_FragColor};
}

function renderAllShapes(){
  g_seconds = performance.now() / 1000.0 - g_startTime;
  if (button){
    console.log('test');
    angleSlider2 = 90+(90*Math.sin(g_seconds));
  }
  var vertexBuffer = gl.createBuffer();
  if (!vertexBuffer) {
    console.log('Failed to create the buffer object');
    return -1;
  }
  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);

  var globalRotMat = new Matrix4().rotate(g_globalAngle, 0, 1, 0);
  gl.uniformMatrix4fv(u_GlobalRotateMatrix, false, globalRotMat.elements);

  updateAnimationAngles();
}

function initVertexBuffers(gl) {
    var vertices = new Float32Array([
      0, 0.5,   -0.5, -0.5,   0.5, -0.5
    ]);
    var n = 3; // The number of vertices
  
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
      console.log('Failed to create the buffer object');
      return -1;
    }
    // Bind the buffer object to target
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    // Write date into the buffer object
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
  
    var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    if (a_Position < 0) {
      console.log('Failed to get the storage location of a_Position');
      return -1;
    }
    // Assign the buffer object to a_Position variable
    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  
    // Enable the assignment to a_Position variable
    gl.enableVertexAttribArray(a_Position);
  
    return n;
  }
    
function renderShape(gl, a_Position, u_FragColor, vertexBuffer, vertices, color, size, renderType){
    //gl.clearColor(0.0, 0.0, 0.0, 1.0);
    // Clear <canvas>
    //gl.clear(gl.COLOR_BUFFER_BIT);
    //let color = shape.color;
    //let vertices = shape.vertices;
    //let size = shape.size;
    //console.log();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.uniform4f(u_FragColor, color[0], color[1], color[2], color[3]);

  gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
  // Enable the assignment to a_Position variable
  gl.enableVertexAttribArray(a_Position);
  gl.drawArrays(renderType, 0, size);

}

function renderTriangle3D(vertexBuffer, verts, color, ){
let n = 3;
var v = new Float32Array(verts); 
gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);

//gl.uniform4f(u_FragColor, color[0], color[1], color[2], color[3]);

gl.bufferData(gl.ARRAY_BUFFER, v, gl.STATIC_DRAW);
gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
// Enable the assignment to a_Position variable
gl.enableVertexAttribArray(a_Position);
gl.drawArrays(gl.TRIANGLES, 0, n);
}


function updateAnimationAngles(){
  var body = new Cube();
  var leftArm;
  var test2 = new Cube();
  var test3 = new Cube();
  var test4 = new Cube();
  const x = 0.25;
  const y = 0.25;
  const z = 0.25;
  body.color = [1.0, 0.0, 1.0, 1.0];
  body.matrix.translate(-0.25, -0.25, 0.0);
  //body.moveYBySin(g_seconds);
  //console.log(body.matrix.elements[13]);
  leftArm = new Cube();
  //leftArm.offset = Math.PI / 2;
  //leftArm.moveYBySin(g_seconds);
  leftArm.matrix = new Matrix4();
  //console.log(leftArm.matrix.elements[13]);
  //console.log(test);
  body.matrix.scale(0.5, .5, 0.5);
  //translate_to(body, leftArm);
  leftArm.matrix.translate(0, 0, 0);
  //body.render();
  leftArm.color = [1.0, 1.0, 0.0, 1.0];
  leftArm.matrix.rotate(angleSlider2, 0, 0, 1);
  leftArm.matrix.scale(x, y, z);

  translate_to(leftArm, test2);
  test2.matrix.rotate((angleSlider2*angleSlider3)/100, 0, 0, 1);
  test2.matrix.scale(x, y, z);
  translate_to(test2, test3, new Vector3([-0.1, 0, -0.1]));
  test3.matrix.rotate((angleSlider2*angleSlider3)/75, 0, 0, 1);
  test3.matrix.scale(x+0.05, y, z+0.05);
  translate_to(test3, test4, new Vector3([0.1, 0, 0.1]));
  test4.matrix.rotate((angleSlider2*angleSlider3)/50, 0, 0, 1);
  test4.matrix.scale(x, y, z);
  //console.log((angleSlider2+angleSlider3)/180);
  //console.log(angleSlider2+(angleSlider3)/90, ":", angleSlider2, " ",(angleSlider3)/90);
  leftArm.render();
  test2.color = [1.0, 1.0, 0.0, 1.0];
  test4.color = [1.0, 0.5, 0.1, 1.0];
  test2.render();
  test3.render();
  test4.render();

}

function translate_to(cube1, cube2, offset){
  let v = new Vector3([0,0.75,0]);
  if (offset){
    v.add(offset);
  }
  let y_vector = cube1.matrix.multiplyVector3(v);
  cube2.matrix.translate(y_vector.elements[0], y_vector.elements[1], y_vector.elements[2]);
}